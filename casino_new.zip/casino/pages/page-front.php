<?php


get_header(); ?>


<?php get_template_part('includes/modules/casino-grid') ?>


<?php get_footer(); ?>