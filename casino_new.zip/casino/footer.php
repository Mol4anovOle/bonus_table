</main><?php // main-container end ?>

<?php include(locate_template('main-vars.php', true)); ?>


<footer class="footer">
    <div class="container">
        <div class="footer__wrap">
            <div class="footer__left">

                <p class="footer__copyright ">Copyright ©<?= date("Y"); ?> <?= get_bloginfo() ?> All
                    rights
                    reserved.</p>

            </div>

        </div>


</footer>

<?php wp_footer(); ?>


</body>
</html>
