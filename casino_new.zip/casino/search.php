
<?php get_header(); ?>

    <section class="search_section">

        <div class="container">
            <h1> Search result</h1>
            <ul>
                <?php if(have_posts()):?><?php while(have_posts()):the_post();?>

                <li>

                    <div class="post" id="post-<?php the_ID();?>">

                        <h2><a href="<?php the_permalink();?>" title="<?php the_title();?>"><?php the_title();?></a></h2>

                        <div class="entry">

                            <?php the_excerpt('');?>

                        </div>

                    </div>

                </li>
     <?php endwhile;?>



            <?php else:?>

            <?php endif;?>
            </ul>


        </div>
    </section>

<?php get_footer(); ?>