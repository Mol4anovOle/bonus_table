<?php
// *********************** |Main php variables| ***************************


$nameDomain = $_SERVER['HTTP_HOST'];
$currency = "€";

?>
