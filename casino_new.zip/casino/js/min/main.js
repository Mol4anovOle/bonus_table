"use strict";

function _typeof(t) {
    "@babel/helpers - typeof";
    return (_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
        return typeof t
    } : function(t) {
        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
    })(t)
}! function(t) {
    "function" == typeof define && define.amd ? define(["jquery"], t) : t("object" === ("undefined" == typeof exports ? "undefined" : _typeof(exports)) ? require("jquery") : jQuery)
}(function(t) {
    function e(t, e) {
        return t.toFixed(e.decimals)
    }
    var o = function e(o, i) {
        this.$element = t(o), this.options = t.extend({}, e.DEFAULTS, this.dataOptions(), i), this.init()
    };
    o.DEFAULTS = {
        from: 0,
        to: 0,
        speed: 1e3,
        refreshInterval: 100,
        decimals: 0,
        formatter: e,
        onUpdate: null,
        onComplete: null
    }, o.prototype.init = function() {
        this.value = this.options.from, this.loops = Math.ceil(this.options.speed / this.options.refreshInterval), this.loopCount = 0, this.increment = (this.options.to - this.options.from) / this.loops
    }, o.prototype.dataOptions = function() {
        var t = {
                from: this.$element.data("from"),
                to: this.$element.data("to"),
                speed: this.$element.data("speed"),
                refreshInterval: this.$element.data("refresh-interval"),
                decimals: this.$element.data("decimals")
            },
            e = Object.keys(t);
        for (var o in e) {
            var i = e[o];
            void 0 === t[i] && delete t[i]
        }
        return t
    }, o.prototype.update = function() {
        this.value += this.increment, this.loopCount++, this.render(), "function" == typeof this.options.onUpdate && this.options.onUpdate.call(this.$element, this.value), this.loopCount >= this.loops && (clearInterval(this.interval), this.value = this.options.to, "function" == typeof this.options.onComplete && this.options.onComplete.call(this.$element, this.value))
    }, o.prototype.render = function() {
        var t = this.options.formatter.call(this.$element, this.value, this.options);
        this.$element.text(t)
    }, o.prototype.restart = function() {
        this.stop(), this.init(), this.start()
    }, o.prototype.start = function() {
        this.stop(), this.render(), this.interval = setInterval(this.update.bind(this), this.options.refreshInterval)
    }, o.prototype.stop = function() {
        this.interval && clearInterval(this.interval)
    }, o.prototype.toggle = function() {
        this.interval ? this.stop() : this.start()
    }, t.fn.countTo = function(e) {
        return this.each(function() {
            var i = t(this),
                n = i.data("countTo"),
                r = !n || "object" === _typeof(e),
                s = "object" === _typeof(e) ? e : {},
                a = "string" == typeof e ? e : "start";
            r && (n && n.stop(), i.data("countTo", n = new o(this, s))), n[a].call(n)
        })
    }
}),
function(t, e, o, i) {
    var n = t(e);
    t.fn.lazyload = function(r) {
        function s() {
            var e = 0;
            l.each(function() {
                var o = t(this);
                if (!f.skip_invisible || o.is(":visible"))
                    if (t.abovethetop(this, f) || t.leftofbegin(this, f));
                    else if (t.belowthefold(this, f) || t.rightoffold(this, f)) {
                    if (++e > f.failure_limit) return !1
                } else o.trigger("appear"), e = 0
            })
        }
        var a, l = this,
            f = {
                threshold: 0,
                failure_limit: 0,
                event: "scroll",
                effect: "show",
                container: e,
                data_attribute: "original",
                skip_invisible: !0,
                appear: null,
                load: null,
                placeholder: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAANSURBVBhXYzh8+PB/AAffA0nNPuCLAAAAAElFTkSuQmCC"
            };
        return r && (i !== r.failurelimit && (r.failure_limit = r.failurelimit, delete r.failurelimit), i !== r.effectspeed && (r.effect_speed = r.effectspeed, delete r.effectspeed), t.extend(f, r)), a = f.container === i || f.container === e ? n : t(f.container), 0 === f.event.indexOf("scroll") && a.bind(f.event, function() {
            return s()
        }), this.each(function() {
            var e = this,
                o = t(e);
            e.loaded = !1, (o.attr("src") === i || !1 === o.attr("src")) && o.is("img") && o.attr("src", f.placeholder), o.one("appear", function() {
                if (!this.loaded) {
                    if (f.appear) {
                        var i = l.length;
                        f.appear.call(e, i, f)
                    }
                    t("<img />").bind("load", function() {
                        var i = o.attr("data-" + f.data_attribute);
                        o.hide(), o.is("img") ? o.attr("src", i) : o.css("background-image", "url('" + i + "')"), o[f.effect](f.effect_speed), e.loaded = !0;
                        var n = t.grep(l, function(t) {
                            return !t.loaded
                        });
                        if (l = t(n), f.load) {
                            var r = l.length;
                            f.load.call(e, r, f)
                        }
                    }).attr("src", o.attr("data-" + f.data_attribute))
                }
            }), 0 !== f.event.indexOf("scroll") && o.bind(f.event, function() {
                e.loaded || o.trigger("appear")
            })
        }), n.bind("resize", function() {
            s()
        }), /(?:iphone|ipod|ipad).*os 5/gi.test(navigator.appVersion) && n.bind("pageshow", function(e) {
            e.originalEvent && e.originalEvent.persisted && l.each(function() {
                t(this).trigger("appear")
            })
        }), t(o).ready(function() {
            s()
        }), this
    }, t.belowthefold = function(o, r) {
        return (r.container === i || r.container === e ? (e.innerHeight ? e.innerHeight : n.height()) + n.scrollTop() : t(r.container).offset().top + t(r.container).height()) <= t(o).offset().top - r.threshold
    }, t.rightoffold = function(o, r) {
        return (r.container === i || r.container === e ? n.width() + n.scrollLeft() : t(r.container).offset().left + t(r.container).width()) <= t(o).offset().left - r.threshold
    }, t.abovethetop = function(o, r) {
        return (r.container === i || r.container === e ? n.scrollTop() : t(r.container).offset().top) >= t(o).offset().top + r.threshold + t(o).height()
    }, t.leftofbegin = function(o, r) {
        return (r.container === i || r.container === e ? n.scrollLeft() : t(r.container).offset().left) >= t(o).offset().left + r.threshold + t(o).width()
    }, t.inviewport = function(e, o) {
        return !(t.rightoffold(e, o) || t.leftofbegin(e, o) || t.belowthefold(e, o) || t.abovethetop(e, o))
    }, t.extend(t.expr[":"], {
        "below-the-fold": function(e) {
            return t.belowthefold(e, {
                threshold: 0
            })
        },
        "above-the-top": function(e) {
            return !t.belowthefold(e, {
                threshold: 0
            })
        },
        "right-of-screen": function(e) {
            return t.rightoffold(e, {
                threshold: 0
            })
        },
        "left-of-screen": function(e) {
            return !t.rightoffold(e, {
                threshold: 0
            })
        },
        "in-viewport": function(e) {
            return t.inviewport(e, {
                threshold: 0
            })
        },
        "above-the-fold": function(e) {
            return !t.belowthefold(e, {
                threshold: 0
            })
        },
        "right-of-fold": function(e) {
            return t.rightoffold(e, {
                threshold: 0
            })
        },
        "left-of-fold": function(e) {
            return !t.rightoffold(e, {
                threshold: 0
            })
        }
    })
}(jQuery, window, document), $(document).ready(function() {
    function t() {
        $("#age-popup").show()
    }
    $("img[data-original]").lazyload({
        effect: "fadeIn"
    }), $.fn.inView = function() {
        var t = $(window);
        window.obj = $(this);
        var e = t.scrollTop(),
            o = t.scrollTop() + t.height(),
            i = window.obj.offset().top + window.obj.outerHeight();
        return o >= i && e <= i
    }, $(".js-hamburger").click(function() {
        $("body").toggleClass("is-open"), $("html").toggleClass("no-scroll")
    }), $(".header__phone, .header__phone--mobile, .footer__phone").on("click", function() {
        $(".cr-cb-button-block").trigger("click")
    }), $(function() {
        $(".header__navigation li a").each(function() {
            window.location.href == this.href && $(this).addClass("active")
        })
    })
    
});