"use strict";
$(document).ready(function () {
    $(".header__logo, .footer__logo").click(function (o) {
        o.preventDefault(), $("html, body").animate({scrollTop: 0}, 700);
    });
    if ($(window).width() > 991) {
        $('.sort_toggle').prependTo($('.title_row'));
    }
    var dataValue=[];
    $('.casino_item').each(function(){
        dataValue.push($(this).attr("data-casino"));

    });
    dataValue.sort(function(a, b) {
        return a === b ? 0 : a < b ? -1 : 1;
    });
    $(".sort_toggle").click(function () {
      if ( $(".sort_toggle").hasClass('active')){
          for (let i = 0; i<dataValue.length; i++){
              $(`[data-casino="${dataValue[i]}"]`).css('order','');

          }
          $(".sort_toggle").toggleClass('active');
      } else{
          for (let i = 0; i<dataValue.length; i++){
              $(`[data-casino="${dataValue[i]}"]`).css('order',`${i+1}`);

          }
          $(".sort_toggle").toggleClass('active');
      }

    });
    $('.view_card').click(function(){
        $('.view_card').toggleClass('active');
        $('.casino_grid').toggleClass('cards_view');
        if ($('.casino_item').hasClass('flex-container')){
            $('.casino_item').each(function(){
                $('.casino_item').removeClass('flex-container').addClass('column');
            })
        } else{
            $('.casino_item').each(function(){
                $('.casino_item').removeClass('column').addClass('flex-container');
            })
        }
    });
    $(".show_all").click(function () {
        $(".casino_item:hidden")
            .slice(0, 100)
            .slideDown({
                start: function () {
                    $(this).css({display: "flex"});
                },
            }),
        $(".casino_item").length == $(".casino_item:visible").length && $(".show_all").hide(),
            $(".casino_item").scroll();
    });

});
