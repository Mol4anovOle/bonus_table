//= include plugins/*

$(document).ready(() => {
    //= include components/helpers.js
    //= include components/header.js
    //= include components/login.js
});
//= include components/calculator.js
//= include components/email-collector.js
