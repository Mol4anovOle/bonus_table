<?php get_header(); ?>

<?php get_template_part('includes/sections/post/seo-top') ?>

    <div class="post">
        <div class="container">
            <?php get_template_part('loop'); ?>
        </div>

      
    </div>

<?php get_footer(); ?>