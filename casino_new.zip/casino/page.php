<?php
/* Template Name: SEO Page */
get_header();

?>


<section>
        <div class="seo-page">
        <div class="container">
            <?php
            if (have_posts()) {
                the_post();
                the_content();
            }
            ?>
        </div>


    </div>
</section>


<?php get_template_part('includes/modules/faq-section')?>
<?php
get_footer();
?>