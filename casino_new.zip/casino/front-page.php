<?php /* Template Name: Front Page */?>

<?php get_template_part('pages/page-front')?>