<div class="casino_grid">
    <?php if (have_rows('casino_item')):
        while (have_rows('casino_item')) : the_row(); ?>
            <div class="casino_item flex-container" data-casino="<?php the_sub_field('casino_name'); ?>">

                <div class="casino_number ">
                    <?php the_row_index(); ?>


                </div>
                <div class="casino_item_image">
                    <?php $image = get_sub_field('casinos_image'); ?>
                    <img  src="<?= bloginfo('template_url') . '/images/loader.gif' ?>"
                         data-original="<?php echo $image['url']; ?>" alt="<?php the_sub_field('casinos_name') ?>">
                </div>
                <div class="casino_item_rating column mobile--hidden">
                    <div class="star_line" >
                        <div class="star_line_mask flex-container">
                            <?php


                            $i = 1;
                            while ($i <= 5) {
                                echo '<i  class="rating_star"></i>';
                                $i++;

                            };

                            ?>
                        </div>
                    </div>

                </div>

                <a href=" <?php the_sub_field('casinos_link') ?>" class="casino_review_link  "><span class="mobile--hidden">Read </span>Review </a>


                <div class="casino_item_title text--center">
                    <div class="casino_title_subtitle desktop--hidden"> <?php the_sub_field('casino_subtitle') ?></div>
                    <div class="casino_title_value desktop--hidden"> <?php the_sub_field('casino_value') ?></div>
                    <div class="casino_title_title mobile--hidden"> <?php the_sub_field('casino_title') ?></div>


                </div>
                <div class="casino_item_buttons">
                    <a rel="sponsored" href="#casinolink" target="_blank"
                       onclick="this.href='<?php the_sub_field('casino_ref_link') ?>'"
                       class="casino--button text--center ">
                        <span class="mobile--hidden">Play Now</span>


                    </a>

                </div>


            </div>
        <?php endwhile; endif; ?>


</div>
<div class="show_all text--center" style="order:99999 ">View All Sports Betting Sites</div>