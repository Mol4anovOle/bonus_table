<section class="section__casino_grid">
    <div id="casinolink" style="display:none"></div>

    <div class="container">
        <?php if (get_field('casino_grid_title')) : ?>
            <div class="title_row flex-container">
                <?php $image = get_field('casino_title_icon'); ?>
                <div class="title_row_with_icon flex-container">
                    <img src="<?php echo($image['url']); ?>" alt="casino_icon">
                    <h1 class="section__title text--capitalize "><?php the_field('casino_grid_title') ?></h1>
                </div>

                <div class="view_card mobile--hidden">Change view

                </div>
            </div>
        <?php endif; ?>

        <div class="sort_toggle">Sort Alphabetically</div>

        <?php get_template_part('includes/modules/casino-table') ?>


    </div>

</section>
