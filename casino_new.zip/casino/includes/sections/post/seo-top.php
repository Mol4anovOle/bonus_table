<section class="seo-top">

    <div class="container seo-top__wrap">

      


        <h1 class="seo-top__title text--capitalize">
            <?= get_the_title() ?>
        </h1>

    </div>

</section>